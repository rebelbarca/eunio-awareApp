var connection = require("../config/connection.js");

var orm = {
  
};

module.exports = orm;
