var lat="";
var long="";

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: -33.865143, lng: 151.209900},
    zoom: 15
  });

  google.maps.event.addListener(map, "click", function (event) {
    var newMark = new google.maps.Marker({
      position: event.latLng,
      map: map,
    });
    lat = event.latLng.lat();
    long = event.latLng.lng();
  });
}

let button = $('#compare');
button.on("click", function(){
    console.log("hi!");
    console.log(lat);
    console.log(long);
    $.ajax("/api/searchrequest", {
        type: "GET",
        lat: -33.865143,
        long: 151.209900
      }).then(
        function() {
          console.log("created new request");
          location.reload();
        }
      );
  });